#!/bin/bash
# log-rotate.sh — Another legitimate-looking script (decoy)
echo "=== Log Rotation ==="
echo "Rotating logs in /var/log/..."
echo "Done. Rotated 0 files."